# Code of Conduct

Be kind. No harassment. No doxxing.

If you need help, open an issue with minimal private data.
