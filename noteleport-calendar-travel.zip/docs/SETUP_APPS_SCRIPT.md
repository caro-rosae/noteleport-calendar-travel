# Apps Script Setup (Detailed)

## 1) Create the project
1. Open https://script.google.com
2. Click **New project**
3. Rename the project (top left) e.g. `NoTeleport`

## 2) Add files
In the left sidebar, click **Files**:
- Create `TravelGenerator.gs` → paste from `apps-script/TravelGenerator.gs`
- Create `WebApp.gs` → paste from `apps-script/WebApp.gs`

## 3) Script Properties (API key)
1. Click **Project Settings** (gear icon)
2. Scroll to **Script Properties**
3. Add:
   - `API_KEY` = a long random secret

## 4) First run (permissions)
1. Select `syncTrajets` in function dropdown
2. Click **Run**
3. Approve permissions

## 5) Trigger (automation)
1. Click **Triggers** (clock icon)
2. Add trigger:
   - function: `syncTrajets`
   - time-driven: every 15 minutes

## 6) Deploy Web App (for extension)
1. **Deploy** → **New deployment**
2. Type: **Web app**
3. Execute as: **Me**
4. Access: **Anyone with the link**
5. Deploy and copy URL
