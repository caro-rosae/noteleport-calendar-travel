# Chrome Extension Setup (Detailed)

## 1) Load unpacked
1. Open Chrome
2. Go to `chrome://extensions`
3. Enable **Developer mode**
4. Click **Load unpacked**
5. Select `chrome-extension/`

## 2) Open options
1. Click the extension card → **Details**
2. Click **Extension options**

## 3) Configure
You need:
- Web App URL (Apps Script deployment)
- API key (Script property `API_KEY`)

Then choose:
- language
- home address
- travel calendar name (optional)
- source calendars
- chaining threshold and gaps

Click **Save**.
This saves locally AND syncs settings to Apps Script.

## 4) Run now
Use:
- Options page “Run now”
- or extension popup “Run now”
