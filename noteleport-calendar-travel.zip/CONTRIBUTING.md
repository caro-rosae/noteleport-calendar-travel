# Contributing

Small PRs welcome.

- Keep the parameter section readable.
- Maintain translations (FR/EN/DE/ES).
- Avoid adding heavy dependencies to the extension.

Please don’t include private addresses or personal data in issues.
