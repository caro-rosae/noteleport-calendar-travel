async function callApi(action, method = "GET") {
  const { webAppUrl, apiKey } = await chrome.storage.sync.get({ webAppUrl: "", apiKey: "" });
  if (!webAppUrl || !apiKey) throw new Error("Missing Web App URL or API key.");
  const url = new URL(webAppUrl);
  url.searchParams.set("action", action);
  url.searchParams.set("api_key", apiKey);
  const res = await fetch(url.toString(), { method });
  const data = await res.json().catch(() => ({}));
  if (!data.ok) throw new Error(data.error || "unknown_error");
  return data;
}

document.addEventListener("DOMContentLoaded", () => {
  const msg = document.getElementById("msg");
  document.getElementById("runBtn").addEventListener("click", async () => {
    msg.textContent = "";
    try {
      await callApi("run", "POST");
      msg.textContent = "OK";
    } catch (e) {
      msg.textContent = `${chrome.i18n.getMessage("error")}: ${e.message}`;
    }
  });
});
