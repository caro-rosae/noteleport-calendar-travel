async function storageGetDefaults() {
  return await chrome.storage.sync.get({
    webAppUrl: "",
    apiKey: "",
    lang: chrome.i18n.getUILanguage().startsWith("fr") ? "fr" : "en",
    homeAddress: "",
    travelCalName: "",
    sourceCals: "",
    chainIntervalMin: 120,
    gapBeforeEventMin: 10,
    gapAfterEventMin: 15
  });
}

function setStatusLine(text) {
  document.getElementById("statusLine").textContent = text;
}

function fmtDate(ms) {
  const d = new Date(ms);
  return d.toLocaleString();
}

async function callApi(action, method = "GET", body = null) {
  const { webAppUrl, apiKey } = await chrome.storage.sync.get({ webAppUrl: "", apiKey: "" });
  if (!webAppUrl || !apiKey) throw new Error(chrome.i18n.getMessage("missing"));
  const url = new URL(webAppUrl);
  url.searchParams.set("action", action);
  url.searchParams.set("api_key", apiKey);

  const res = await fetch(url.toString(), {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : null
  });
  const data = await res.json().catch(() => ({}));
  if (!data.ok) throw new Error(data.error || "unknown_error");
  return data;
}

async function refreshStatus() {
  try {
    const data = await callApi("status");
    const cd = data.cooldown_until_ms;
    if (cd) setStatusLine(`${chrome.i18n.getMessage("cooldown")}: ${fmtDate(cd)}`);
    else setStatusLine(`${chrome.i18n.getMessage("cooldown")}: ${chrome.i18n.getMessage("none")}`);
  } catch (e) {
    setStatusLine(`${chrome.i18n.getMessage("error")}: ${e.message}`);
  }
}

async function load() {
  const s = await storageGetDefaults();
  document.getElementById("webAppUrl").value = s.webAppUrl;
  document.getElementById("apiKey").value = s.apiKey;
  document.getElementById("lang").value = s.lang;

  document.getElementById("homeAddress").value = s.homeAddress;
  document.getElementById("travelCalName").value = s.travelCalName;
  document.getElementById("sourceCals").value = s.sourceCals;

  document.getElementById("chainInterval").value = s.chainIntervalMin;
  document.getElementById("gapBefore").value = s.gapBeforeEventMin;
  document.getElementById("gapAfter").value = s.gapAfterEventMin;

  await refreshStatus();
}

async function saveAndSync() {
  const webAppUrl = document.getElementById("webAppUrl").value.trim();
  const apiKey = document.getElementById("apiKey").value.trim();
  const uiLang = document.getElementById("lang").value;

  const homeAddress = document.getElementById("homeAddress").value.trim();
  const travelCalName = document.getElementById("travelCalName").value.trim();
  const sourceCalNames = document.getElementById("sourceCals").value.trim();

  const chainIntervalMin = Number(document.getElementById("chainInterval").value);
  const gapBeforeEventMin = Number(document.getElementById("gapBefore").value);
  const gapAfterEventMin = Number(document.getElementById("gapAfter").value);

  await chrome.storage.sync.set({
    webAppUrl, apiKey, lang: uiLang,
    homeAddress, travelCalName, sourceCals: sourceCalNames,
    chainIntervalMin, gapBeforeEventMin, gapAfterEventMin
  });

  // Push to Apps Script
  try {
    await callApi("settings", "POST", {
      uiLang,
      homeAddress,
      travelCalName, // empty => localized default in Apps Script
      sourceCalNames,
      chainIntervalMin,
      gapBeforeEventMin,
      gapAfterEventMin
    });
    setStatusLine(chrome.i18n.getMessage("saved"));
    await refreshStatus();
  } catch (e) {
    setStatusLine(`${chrome.i18n.getMessage("error")}: ${e.message}`);
  }
}

async function runNow() {
  try {
    await callApi("run", "POST");
    await refreshStatus();
  } catch (e) {
    setStatusLine(`${chrome.i18n.getMessage("error")}: ${e.message}`);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("saveBtn").addEventListener("click", saveAndSync);
  document.getElementById("runBtn").addEventListener("click", runNow);
  load();
});
